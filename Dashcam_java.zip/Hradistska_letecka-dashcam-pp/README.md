# Hradistska_letecka-dashcam
Aplikace zaznamenávající události během jízdy.
***********************
Zásady ochrany osobních údajů
Aplikace nezpracovává ani NESBÍRÁ ŽÁDNÉ SOUBORY.
